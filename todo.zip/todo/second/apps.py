from django.apps import AppConfig


class SecondConfig(AppConfig):
    name = 'second'
